# SimpleGallery

A simple image gallery application built with React Native.

## Get stared

1. Install dependencies

   ```bash
   npm install
   ```

2. Start the app

   ```bash
   npx expo start
   ```

## Features

- Thumbnail images in a grid view 
- Caption display
- Large viewer for the selected image at the top
- Placeholder message on initial load

## Technologies

- **React Native**
- **FlatList**
- **Expo**
- **useState Hook** 
- **StyleSheet**